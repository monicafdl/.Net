﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    class Avaliacao
    {
        public Int64 codigo { set; get; }

        public Int64 valor { set; get; }
        public Diario Ava_Diario { get => Ava_Diario; set => Ava_Diario = value; }
        public Aluno Ava_Aluno { get => Ava_Aluno; set => Ava_Aluno = value; }

        
    }
}
