﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    class Disciplina
    {
        public Int64 codigo { set; get; }

        public String descricao { set; get; }
    }
}
