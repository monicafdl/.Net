﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    class Diario
    {
        public Int64 codigo { set; get; }
        public Disciplina Diario_Disciplina { get => Diario_Disciplina; set => Diario_Disciplina = value; }
        public Avaliacao Diario_Avaliacao { get => Diario_Avaliacao; set => Diario_Avaliacao = value; }
        public List<Aluno> Diario_Alunos { get => Diario_Alunos; set => Diario_Alunos = value; }
    }
}
