﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Aluno
    {
        #region Atributos

        public Int64 matricula { set; get; }
        
        //Declaração Implícita
        public String Nome { set; get; }
        internal Diario Aluno_Diario { get => Aluno_Diario; set => Aluno_Diario = value; }
        internal List<Avaliacao> Aluno_Avaliacoes { get => Aluno_Avaliacoes; set => Aluno_Avaliacoes = value; }

   
        #endregion

        #region Métodos
        //Implementação dos métodos
        #endregion
    }
}
