﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    class Compra
    {
        #region Atributos

        public Int64 Id { set; get; }

        public String Nome { set; get; }

        public String Produto { set; get; }

        public Int32 Codigo { set; get; }

        public Double Valor{ set; get; }

        public DateTime Data { set; get; }

       
        #endregion

        #region Métodos
        //Implementação dos métodos
        #endregion

    }
}
