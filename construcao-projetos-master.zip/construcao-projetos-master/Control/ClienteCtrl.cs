﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Dao;

namespace Control
{
    public class ClienteCtrl
    {
        public Boolean SalvarClienteNoArquivo(Cliente _c)
        {
            try
            {
                ClienteDAO dao = new ClienteDAO();

                dao.SalvarClienteNoArquivo(_c);

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public Dictionary<Int64, Cliente> ListarClienteDoArquivo()
        {
            try
            {
                Dictionary<Int64, Cliente> mapaCliente = new Dictionary<Int64, Cliente>();
                ClienteDAO dao = new ClienteDAO();

                foreach (Cliente o in dao.ListarClienteDoArquivo())
                {
                    mapaCliente.Add(o.Id, o);
                }

                return mapaCliente;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
