﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dao
{
    class ProdutoDAO
    {
        public Boolean SalvarProdutoNoArquivo(Produto _p)
        {
            String dir = AppDomain.CurrentDomain.BaseDirectory;
            String path =  dir + "bd.txt";
            try
            {
                StreamWriter escritor = new StreamWriter(path, true);

                escritor.Write(_c.Id + ";");
                escritor.Write(_c.Nome + ";");
                escritor.Write(_c.Telefone + ";");
                escritor.Write(_c.Email + ";");
                escritor.Write(_c.TipoEndereco + ";");
                escritor.Write(_c.Endereco + ";");
                escritor.Write(_c.Estado + ";");
                escritor.Write(_c.Cidade + ";");
                escritor.Write(_c.Sexo + ";");
                
                escritor.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return true;
        }

        public List<Cliente> ListarClienteDoArquivo()
        {
            List<Cliente> listaCliente = new List<Cliente>();
            try
            {
                String dir = AppDomain.CurrentDomain.BaseDirectory;
                String path = dir + "bd.txt";

                StreamReader leitor = new StreamReader(path);
                
                String arquivo = leitor.ReadToEnd();

                Char[] separadorLinhas = { '\n' };
                Char[] separadorColunas = { ';' };

                String[] linhas = arquivo.Split(separadorLinhas);
                for (int i = 0; i < linhas.Length - 1; i++)
                {
                    Cliente c = new Cliente();

                    String[] colunas = linhas[i].Split(separadorColunas);


                    c.Id = Convert.ToInt64(colunas[0]);
                    c.Nome = colunas[1];
                    c.Telefone = colunas[2];
                    c.Email = colunas[3];
                    c.TipoEndereco = Convert.ToInt32(colunas[4]);
                    c.Endereco = colunas[5];
                    c.Estado = Convert.ToInt32(colunas[6]);
                    c.Cidade = Convert.ToInt32(colunas[7]);
                    c.Sexo = colunas[8];
  
                    listaCliente.Add(c);
                }
                leitor.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return listaCliente;
        }
   
    
    }
}
