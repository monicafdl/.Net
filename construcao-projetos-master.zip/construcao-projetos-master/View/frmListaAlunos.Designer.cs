﻿namespace View
{
    partial class frmListaAlunos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFechar = new System.Windows.Forms.Button();
            this.btnImprimir = new System.Windows.Forms.Button();
            this.documento = new System.Drawing.Printing.PrintDocument();
            this.janelaImpressao = new System.Windows.Forms.PrintDialog();
            this.dgvAlunos = new System.Windows.Forms.DataGridView();
            this.gcolID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gcolNome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gcolEmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gpbPessoas = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlunos)).BeginInit();
            this.gpbPessoas.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(319, 267);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(75, 23);
            this.btnFechar.TabIndex = 7;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            // 
            // btnImprimir
            // 
            this.btnImprimir.Location = new System.Drawing.Point(18, 267);
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(75, 23);
            this.btnImprimir.TabIndex = 8;
            this.btnImprimir.Text = "Imprimir";
            this.btnImprimir.UseVisualStyleBackColor = true;
            // 
            // janelaImpressao
            // 
            this.janelaImpressao.UseEXDialog = true;
            // 
            // dgvAlunos
            // 
            this.dgvAlunos.AllowUserToAddRows = false;
            this.dgvAlunos.AllowUserToDeleteRows = false;
            this.dgvAlunos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAlunos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.gcolID,
            this.gcolNome,
            this.gcolEmail});
            this.dgvAlunos.Location = new System.Drawing.Point(6, 21);
            this.dgvAlunos.Name = "dgvAlunos";
            this.dgvAlunos.ReadOnly = true;
            this.dgvAlunos.RowHeadersVisible = false;
            this.dgvAlunos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAlunos.Size = new System.Drawing.Size(388, 217);
            this.dgvAlunos.TabIndex = 4;
            // 
            // gcolID
            // 
            this.gcolID.HeaderText = "Matricula";
            this.gcolID.Name = "gcolID";
            this.gcolID.ReadOnly = true;
            // 
            // gcolNome
            // 
            this.gcolNome.HeaderText = "Nome";
            this.gcolNome.Name = "gcolNome";
            this.gcolNome.ReadOnly = true;
            this.gcolNome.Width = 130;
            // 
            // gcolEmail
            // 
            this.gcolEmail.HeaderText = "Diario";
            this.gcolEmail.Name = "gcolEmail";
            this.gcolEmail.ReadOnly = true;
            this.gcolEmail.Width = 150;
            // 
            // gpbPessoas
            // 
            this.gpbPessoas.Controls.Add(this.dgvAlunos);
            this.gpbPessoas.Location = new System.Drawing.Point(12, 12);
            this.gpbPessoas.Name = "gpbPessoas";
            this.gpbPessoas.Size = new System.Drawing.Size(394, 238);
            this.gpbPessoas.TabIndex = 6;
            this.gpbPessoas.TabStop = false;
            this.gpbPessoas.Text = "Lista de Alunos";
            // 
            // frmListaAlunos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(418, 318);
            this.Controls.Add(this.btnImprimir);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.gpbPessoas);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmListaAlunos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alunos Cadastradas";
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlunos)).EndInit();
            this.gpbPessoas.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Button btnImprimir;
        private System.Drawing.Printing.PrintDocument documento;
        private System.Windows.Forms.PrintDialog janelaImpressao;
        private System.Windows.Forms.DataGridView dgvAlunos;
        private System.Windows.Forms.DataGridViewTextBoxColumn gcolID;
        private System.Windows.Forms.DataGridViewTextBoxColumn gcolNome;
        private System.Windows.Forms.DataGridViewTextBoxColumn gcolEmail;
        private System.Windows.Forms.GroupBox gpbPessoas;
    }
}