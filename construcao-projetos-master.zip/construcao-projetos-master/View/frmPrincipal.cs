﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using Control;

namespace View
{
    public partial class frmPrincipal : Form
    {

        private Dictionary<Int64, Cliente> mapaCliente;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            AbrirFormCadCompra();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            this.Hide();
            
            frmLogin form = new frmLogin();

            if (form.ShowDialog() != DialogResult.OK)
            {
                this.Close();
            }
            else
            {
                this.Show();

                Usuario user = (Usuario)form.Tag;

                sUser.Text = " | Usuário logado: " + user.Login;

                tmHora.Enabled = true;

                CarregarListaCliente();
            }
        }

        private void tmHora_Tick(object sender, EventArgs e)
        {
            itsLabelHora.Text = DateTime.Now.ToLongTimeString();
        }

        private void cadastrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AbrirFormCadCliente();
        }

        private void listarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmListaCliente form = new frmListaCliente();

            form.Tag = mapaCliente;

            form.ShowDialog();
        }

        private void AbrirFormCadCliente()
        {
            frmCadCliente form = new frmCadCliente();

            Int64 ultimaChave = mapaCliente.Keys.Max() + 1;

            form.Tag = ultimaChave;

            form.ShowDialog();
        }

        private void CarregarListaCliente()
        {
            try
            {
                ClienteCtrl control = new ClienteCtrl();

                mapaCliente = control.ListarClienteDoArquivo();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO AO CARREGAR LISTA DE CLIENTE: " + ex.Message);
            }
        }
    }
}
