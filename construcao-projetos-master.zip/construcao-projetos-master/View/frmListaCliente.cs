﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Control;
using Model;
using System.IO;

namespace View
{
    public partial class frmListaCliente : Form
    {
        private Cliente c;

        public frmListaCliente()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmListaCliente_Load(object sender, EventArgs e)
        {
            CarregarMapaCliente();
        }

        private void CarregarMapaCliente()
        {
            Dictionary<Int64, Cliente> mapaCliente = (Dictionary<Int64, Cliente>)this.Tag;
            foreach (Cliente o in mapaCliente.Values)
            {
                dgvDados.Rows.Add(o.Id, o.Nome, o.Email);
            }
        }

        private void dgvDados_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                Int64 idCliente = Convert.ToInt64(dgvDados.SelectedRows[0].Cells[0].Value);

                Dictionary<Int64, Cliente> mapaCliente = (Dictionary<Int64, Cliente>)this.Tag;

                Cliente c = mapaCliente[idCliente];

                frmCadCliente form = new frmCadCliente();

                form.Tag = c;

                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO AO SELECIONAR LINHA: " + ex.Message);
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            try
            {
                Int64 idCliente = Convert.ToInt64(dgvDados.SelectedRows[0].Cells[0].Value);

                Dictionary<Int64, Cliente> mapaCliente = (Dictionary<Int64, Cliente>)this.Tag;

                c = mapaCliente[idCliente];

                if (janelaImpressao.ShowDialog() == DialogResult.OK)
                {
                    documento.Print();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO AO IMPRIMIR LINHA: " + ex.Message);
            }
        }

        private void documento_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            StringBuilder data = new StringBuilder();
            StringWriter escritor = new StringWriter(data);

            Cliente _cliente = c;

            escritor.WriteLine(_cliente.Id + ";");
            escritor.WriteLine(_cliente.Nome + ";");
            escritor.WriteLine(_cliente.Telefone + ";");
            escritor.WriteLine(_cliente.TipoEndereco + ";");
            escritor.WriteLine(_cliente.Endereco + ";");
            escritor.WriteLine(_cliente.Cidade + ";");
            escritor.WriteLine(_cliente.Estado + ";");
            escritor.WriteLine(_cliente.Sexo + ";");
            

            escritor.WriteLine();

            escritor.WriteLine(String.Format("\n\n\nData/Hora do Cadastro: {0}", DateTime.Now.ToString()));

            escritor.Close();

            float leftMargin = e.MarginBounds.Left;
            float topMargin = e.MarginBounds.Top;
            float yPos = 0;

            Font printFont = new Font("Arial", 12);
            yPos = topMargin + printFont.GetHeight(e.Graphics);
            e.HasMorePages = false;
            e.Graphics.DrawString(data.ToString(), printFont, Brushes.Black, leftMargin, yPos, new StringFormat());
        }

    }
}
