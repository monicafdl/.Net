﻿namespace View
{
    partial class frmCadDiario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDiaAva = new System.Windows.Forms.TextBox();
            this.lblDiarCodigo = new System.Windows.Forms.Label();
            this.txtDiaDis = new System.Windows.Forms.TextBox();
            this.txtDiaCodigo = new System.Windows.Forms.TextBox();
            this.lbtDiaAlu = new System.Windows.Forms.ListBox();
            this.lbDiaAlu = new System.Windows.Forms.Label();
            this.lblDiaAva = new System.Windows.Forms.Label();
            this.lblDiaDis = new System.Windows.Forms.Label();
            this.btnDCadastrar = new System.Windows.Forms.Button();
            this.ctnDCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtDiaAva
            // 
            this.txtDiaAva.Location = new System.Drawing.Point(114, 105);
            this.txtDiaAva.Name = "txtDiaAva";
            this.txtDiaAva.Size = new System.Drawing.Size(100, 20);
            this.txtDiaAva.TabIndex = 16;
            // 
            // lblDiarCodigo
            // 
            this.lblDiarCodigo.AutoSize = true;
            this.lblDiarCodigo.Location = new System.Drawing.Point(7, 42);
            this.lblDiarCodigo.Name = "lblDiarCodigo";
            this.lblDiarCodigo.Size = new System.Drawing.Size(86, 13);
            this.lblDiarCodigo.TabIndex = 9;
            this.lblDiarCodigo.Text = "Codigo do diario:";
            // 
            // txtDiaDis
            // 
            this.txtDiaDis.Location = new System.Drawing.Point(114, 73);
            this.txtDiaDis.Name = "txtDiaDis";
            this.txtDiaDis.Size = new System.Drawing.Size(100, 20);
            this.txtDiaDis.TabIndex = 15;
            // 
            // txtDiaCodigo
            // 
            this.txtDiaCodigo.Location = new System.Drawing.Point(114, 39);
            this.txtDiaCodigo.Name = "txtDiaCodigo";
            this.txtDiaCodigo.Size = new System.Drawing.Size(100, 20);
            this.txtDiaCodigo.TabIndex = 14;
            // 
            // lbtDiaAlu
            // 
            this.lbtDiaAlu.FormattingEnabled = true;
            this.lbtDiaAlu.Location = new System.Drawing.Point(114, 147);
            this.lbtDiaAlu.Name = "lbtDiaAlu";
            this.lbtDiaAlu.Size = new System.Drawing.Size(100, 56);
            this.lbtDiaAlu.TabIndex = 13;
            // 
            // lbDiaAlu
            // 
            this.lbDiaAlu.AutoSize = true;
            this.lbDiaAlu.Location = new System.Drawing.Point(12, 147);
            this.lbDiaAlu.Name = "lbDiaAlu";
            this.lbDiaAlu.Size = new System.Drawing.Size(42, 13);
            this.lbDiaAlu.TabIndex = 12;
            this.lbDiaAlu.Text = "Alunos:";
            // 
            // lblDiaAva
            // 
            this.lblDiaAva.AutoSize = true;
            this.lblDiaAva.Location = new System.Drawing.Point(7, 108);
            this.lblDiaAva.Name = "lblDiaAva";
            this.lblDiaAva.Size = new System.Drawing.Size(107, 13);
            this.lblDiaAva.TabIndex = 11;
            this.lblDiaAva.Text = "Codigo da avaliação:";
            // 
            // lblDiaDis
            // 
            this.lblDiaDis.AutoSize = true;
            this.lblDiaDis.Location = new System.Drawing.Point(7, 76);
            this.lblDiaDis.Name = "lblDiaDis";
            this.lblDiaDis.Size = new System.Drawing.Size(104, 13);
            this.lblDiaDis.TabIndex = 10;
            this.lblDiaDis.Text = "Codigo da disciplina:";
            // 
            // btnDCadastrar
            // 
            this.btnDCadastrar.Location = new System.Drawing.Point(246, 54);
            this.btnDCadastrar.Name = "btnDCadastrar";
            this.btnDCadastrar.Size = new System.Drawing.Size(78, 21);
            this.btnDCadastrar.TabIndex = 17;
            this.btnDCadastrar.Text = "Cadastrar";
            this.btnDCadastrar.UseVisualStyleBackColor = true;
            // 
            // ctnDCancelar
            // 
            this.ctnDCancelar.Location = new System.Drawing.Point(246, 137);
            this.ctnDCancelar.Name = "ctnDCancelar";
            this.ctnDCancelar.Size = new System.Drawing.Size(78, 23);
            this.ctnDCancelar.TabIndex = 18;
            this.ctnDCancelar.Text = "Cancelar";
            this.ctnDCancelar.UseVisualStyleBackColor = true;
            // 
            // frmCadDiario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 269);
            this.Controls.Add(this.ctnDCancelar);
            this.Controls.Add(this.btnDCadastrar);
            this.Controls.Add(this.txtDiaAva);
            this.Controls.Add(this.lblDiarCodigo);
            this.Controls.Add(this.txtDiaDis);
            this.Controls.Add(this.txtDiaCodigo);
            this.Controls.Add(this.lbtDiaAlu);
            this.Controls.Add(this.lbDiaAlu);
            this.Controls.Add(this.lblDiaAva);
            this.Controls.Add(this.lblDiaDis);
            this.Name = "frmCadDiario";
            this.Text = "frmCadDiario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDiaAva;
        private System.Windows.Forms.Label lblDiarCodigo;
        private System.Windows.Forms.TextBox txtDiaDis;
        private System.Windows.Forms.TextBox txtDiaCodigo;
        private System.Windows.Forms.ListBox lbtDiaAlu;
        private System.Windows.Forms.Label lbDiaAlu;
        private System.Windows.Forms.Label lblDiaAva;
        private System.Windows.Forms.Label lblDiaDis;
        private System.Windows.Forms.Button btnDCadastrar;
        private System.Windows.Forms.Button ctnDCancelar;
    }
}