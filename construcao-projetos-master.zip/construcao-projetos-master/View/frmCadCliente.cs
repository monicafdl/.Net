﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Control;

namespace View
{
    public partial class frmCadCliente : Form
    {
        private Cliente c = new Cliente();

        public frmCadCliente()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente cliente = CarregarClienteDoForm();

                //Enviar objeto para camada de controle para Salvar no arquivo
                ClienteCtrl control = new ClienteCtrl();

                Boolean teste = control.SalvarClienteNoArquivo(cliente);

                if (teste)
                {
                    MessageBox.Show("Cliente cadastrada com sucesso!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO AO CADASTRAR CLIENTE: " + ex.Message);
            }
            
        }


        public Cliente CarregarClienteDoForm()
        {
            try
            {
                c.Id = (Int64)this.Tag;
                c.Nome = txbNome.Text;
                c.Telefone = mtbTel.Text;
                c.Email = txbEmail.Text;
                c.TipoEndereco = ltbTipoEndereco.SelectedIndex;
                c.Endereco = txbEndereco.Text;
                c.Estado = cmbEstado.SelectedIndex;
                c.Cidade = cmbCidade.SelectedIndex;

                if (rdbMasculino.Checked)
                {
                    c.Sexo = "masculino";
                }
                if (rdbFeminino.Checked)
                {
                    c.Sexo = "feminino";
                }

               ;
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO ao carregar usuário: " + ex.Message);
            }

            return c;
        }

        private void ptbFoto_Click(object sender, EventArgs e)
        {
            if (janelaAbrirArquivo.ShowDialog() == DialogResult.OK)
            {
                c.Imagem = janelaAbrirArquivo.FileName;
            }
        }

        private void txbNome_Click(object sender, EventArgs e)
        {
            txbNome.Text = "";
        }

        private void frmCadCliente_Load(object sender, EventArgs e)
        {
            if (this.Tag != null &&  this.Tag is Cliente)
            {
                btnAlterar.Visible = true;
                btnCadastrar.Visible = false;

                Cliente c = (Cliente)this.Tag;

                CarregarFormDeCliente(c);
            }
        }

        private void CarregarFormDeCliente(Cliente c)
        {
            try
            {

                txbNome.Text = c.Nome;
                mtbTel.Text = c.Telefone;
                txbEmail.Text = c.Email;
                ltbTipoEndereco.SelectedIndex = c.TipoEndereco;
                txbEndereco.Text = c.Endereco;
                cmbEstado.SelectedIndex = c.Estado;
                cmbCidade.SelectedIndex = c.Cidade;

                if (c.Sexo.Equals("masculino"))
                {
                    rdbMasculino.Checked = true;
                }
                else
                {
                    rdbFeminino.Checked = true;
                }

               
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO ao carregar o FORM: " + ex.Message);
            }
        }
    
        
    }
}
